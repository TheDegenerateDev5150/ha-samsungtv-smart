#!/usr/bin/env python3
"""
Samsung TV JSON-RPC parameter/state discovery helper.

Goal:
  Discover whether methods behave like artModeControl:
  - call with only AccessToken
  - inspect returned result fields
  - infer possible parameter names
  - optionally test "echo-back" values from state as setter params

No external dependency required. Uses Python standard library only.

Examples:
  python3 samsung_rpc_discover_params.py --host 192.168.1.161
  python3 samsung_rpc_discover_params.py --host 192.168.1.161 --port 1516
  python3 samsung_rpc_discover_params.py --host 192.168.1.161 --safe-setters
  python3 samsung_rpc_discover_params.py --host 192.168.1.161 --methods artModeControl,getTVStates,getVideoStates
"""

import argparse
import copy
import http.client
import json
import os
import ssl
import sys
import time
from typing import Any, Dict, List, Optional, Tuple


DEFAULT_METHODS = [
    # Confirmed / likely getters or getter-setter hybrids
    "artModeControl",
    "getTVStates",
    "getVideoStates",

    # Known Samsung IP/JSON-RPC methods seen in CI/IP command lists and libraries
    "powerControl",
    "remoteKeyControl",
    "directVolumeControl",
    "volumeUpDnControl",
    "muteControl",
    "channelUpDnControl",
    "directChannelControl",
    "inputSourceControl",
    "USBSourceControl",
    "externalSpeakerControl",
    "directAccessControl",
    "pictureModeControl",
    "pictureSizeControl",
    "soundModeControl",
    "speakerSelectControl",
    "contrastControl",
    "brightnessControl",
    "sharpnessControl",
    "colorControl",
    "tintControl",

    # Occasionally referenced / model-dependent
    "RVUSourceControl",
    "ambientModeControl",
    "artmodeControl",
    "ArtModeControl",
]

# Methods for which setting the returned current value is usually low-risk.
# It may still cause an OSD popup or reapply a setting.
SAFE_ECHO_SETTER_METHODS = {
    "artModeControl": ["artMode"],
    "directVolumeControl": ["volume"],
    "muteControl": ["mute"],
    "inputSourceControl": ["inputSource"],
    "pictureModeControl": ["pictureMode"],
    "pictureSizeControl": ["pictureSize"],
    "soundModeControl": ["soundMode"],
    "speakerSelectControl": ["speakerSelect"],
    "contrastControl": ["contrast"],
    "brightnessControl": ["brightness"],
    "sharpnessControl": ["sharpness"],
    "colorControl": ["color"],
    "tintControl": ["tint"],
}

# Alternative parameter names to test using the same current value.
# Useful when getter field name differs from setter param name.
ALIAS_PARAM_NAMES = {
    "artModeControl": {
        "artMode": ["artMode", "mode", "status"],
    },
    "directVolumeControl": {
        "volume": ["volume", "Volume", "volumeLevel", "directVolume"],
    },
    "muteControl": {
        "mute": ["mute", "Mute", "status", "muteStatus"],
    },
    "inputSourceControl": {
        "inputSource": ["inputSource", "source", "input", "Source"],
    },
    "pictureModeControl": {
        "pictureMode": ["pictureMode", "mode", "PictureMode"],
    },
    "pictureSizeControl": {
        "pictureSize": ["pictureSize", "size", "PictureSize"],
    },
    "soundModeControl": {
        "soundMode": ["soundMode", "mode", "SoundMode"],
    },
    "speakerSelectControl": {
        "speakerSelect": ["speakerSelect", "speaker", "speakerType"],
    },
    "contrastControl": {
        "contrast": ["contrast", "value"],
    },
    "brightnessControl": {
        "brightness": ["brightness", "value"],
    },
    "sharpnessControl": {
        "sharpness": ["sharpness", "value"],
    },
    "colorControl": {
        "color": ["color", "value"],
    },
    "tintControl": {
        "tint": ["tint", "value"],
    },
}

# Param names to probe with harmless/null-ish values.
# These are not guaranteed harmless; by default this is NOT run unless --probe-param-names is provided.
PARAM_NAME_PROBES = {
    "remoteKeyControl": [
        ("remoteKey", "__invalid__"),
        ("key", "__invalid__"),
    ],
    "volumeUpDnControl": [
        ("control", "__invalid__"),
        ("volume", "__invalid__"),
    ],
    "channelUpDnControl": [
        ("control", "__invalid__"),
        ("channel", "__invalid__"),
    ],
    "directAccessControl": [
        ("applicationName", "__invalid__"),
        ("app", "__invalid__"),
        ("url", "about:blank"),
    ],
    "powerControl": [
        ("power", "__invalid__"),
        ("status", "__invalid__"),
    ],
}


def _script_dir() -> str:
    """Directory containing this script, resolved through any symlinks."""
    return os.path.dirname(os.path.abspath(__file__))


def token_path(host: str, port: int) -> str:
    """Token file lives next to the script (not in $HOME)."""
    return os.path.join(_script_dir(), f".samsungtv_jsonrpc_{host}_{port}.token")


def _legacy_token_path(host: str, port: int) -> str:
    """Earlier versions of this script stored tokens in $HOME — keep reading
    those so users don't have to re-pair after the path move."""
    return os.path.expanduser(f"~/.samsungtv_jsonrpc_{host}_{port}.token")


def load_token(host: str, port: int) -> Optional[str]:
    for path in (token_path(host, port), _legacy_token_path(host, port)):
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read().strip() or None
    return None


class SamsungJsonRpc:
    def __init__(self, host: str, port: int, token: str, timeout: int = 10, delay: float = 0.2):
        self.host = host
        self.port = port
        self.token = token
        self.timeout = timeout
        self.delay = delay
        self._id = 0
        self.ssl_context = ssl._create_unverified_context()

    def next_id(self) -> int:
        self._id += 1
        return self._id

    def call(self, method: str, params: Optional[Dict[str, Any]] = None, include_token: bool = True) -> Dict[str, Any]:
        if self.delay:
            time.sleep(self.delay)

        payload: Dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self.next_id(),
        }

        final_params: Dict[str, Any] = {}
        if include_token:
            final_params["AccessToken"] = self.token
        if params:
            final_params.update(params)
        if final_params:
            payload["params"] = final_params

        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")

        conn = http.client.HTTPSConnection(
            self.host,
            self.port,
            timeout=self.timeout,
            context=self.ssl_context,
        )

        try:
            conn.request(
                "POST",
                "/",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "Content-Length": str(len(body)),
                },
            )
            resp = conn.getresponse()
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                parsed = json.loads(raw)
            except Exception:
                parsed = raw

            return {
                "http_status": resp.status,
                "http_reason": resp.reason,
                "request": payload,
                "response": parsed,
            }
        finally:
            conn.close()


def classify_response(res: Dict[str, Any]) -> Tuple[str, Optional[int], str]:
    response = res.get("response")
    if isinstance(response, dict):
        if "result" in response:
            return "RESULT", None, ""
        if "error" in response:
            err = response.get("error") or {}
            if isinstance(err, dict):
                return "ERROR", err.get("code"), str(err.get("message", ""))
            return "ERROR", None, str(err)
    return "OTHER", None, repr(response)


def get_result(res: Dict[str, Any]) -> Optional[Any]:
    response = res.get("response")
    if isinstance(response, dict) and "result" in response:
        return response["result"]
    return None


def compact(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def print_section(title: str) -> None:
    print()
    print("=" * 100)
    print(title)
    print("=" * 100)


def main() -> int:
    parser = argparse.ArgumentParser(description="Samsung TV JSON-RPC parameter discovery")
    parser.add_argument("--host", required=True, help="TV IP, e.g. 192.168.1.161")
    parser.add_argument("--port", type=int, default=1516)
    parser.add_argument("--token", help="AccessToken. If omitted, loads ~/.samsungtv_jsonrpc_<host>_<port>.token")
    parser.add_argument("--timeout", type=int, default=10)
    parser.add_argument("--delay", type=float, default=0.25, help="Delay between calls in seconds")
    parser.add_argument("--methods", help="Comma-separated method list. Default: built-in list")
    parser.add_argument("--safe-setters", action="store_true", help="Reapply current returned values to infer setter param names")
    parser.add_argument("--probe-param-names", action="store_true", help="Probe selected param names with invalid/null-ish values")
    parser.add_argument("--json-out", default="samsung_rpc_discovery_results.json", help="Write full JSON results to this file")
    args = parser.parse_args()

    token = args.token or load_token(args.host, args.port)
    if not token:
        print("No token found.", file=sys.stderr)
        print(f"Run first: python3 samsung_rpc.py --host {args.host} --port {args.port} token", file=sys.stderr)
        print(f"Or pass --token TOKEN", file=sys.stderr)
        return 2

    methods = [m.strip() for m in args.methods.split(",")] if args.methods else DEFAULT_METHODS
    methods = [m for m in methods if m]

    client = SamsungJsonRpc(args.host, args.port, token, timeout=args.timeout, delay=args.delay)

    full_results: Dict[str, Any] = {
        "host": args.host,
        "port": args.port,
        "methods": {},
        "summary": {},
    }

    print_section("1) Baseline calls: method with AccessToken only")
    baseline_results: Dict[str, Dict[str, Any]] = {}

    for method in methods:
        try:
            res = client.call(method)
        except Exception as e:
            print(f"{method:30} EXCEPTION {e!r}")
            full_results["methods"][method] = {"baseline_exception": repr(e)}
            continue

        baseline_results[method] = res
        status, code, msg = classify_response(res)
        result = get_result(res)

        if status == "RESULT":
            print(f"{method:30} RESULT  {compact(result)}")
        elif status == "ERROR":
            print(f"{method:30} ERROR   code={code} msg={msg}")
        else:
            print(f"{method:30} OTHER   {compact(res.get('response'))}")

        full_results["methods"].setdefault(method, {})["baseline"] = res

    print_section("2) Inferred getter-like methods and fields")
    inferred_fields: Dict[str, Dict[str, Any]] = {}

    for method, res in baseline_results.items():
        result = get_result(res)
        if isinstance(result, dict) and result:
            fields = {k: v for k, v in result.items()}
            inferred_fields[method] = fields
            print(f"{method:30} fields={list(fields.keys())} values={compact(fields)}")

    if not inferred_fields:
        print("No getter-like result fields found.")

    full_results["summary"]["inferred_fields"] = inferred_fields

    if args.safe_setters:
        print_section("3) Safe setter echo tests: reapply current getter value")
        print("These calls may reapply current TV settings. They should be low-risk but are not purely read-only.")

        for method, fields in inferred_fields.items():
            allowed_fields = SAFE_ECHO_SETTER_METHODS.get(method, [])
            if not allowed_fields:
                continue

            for field in allowed_fields:
                if field not in fields:
                    continue

                current_value = fields[field]
                aliases = ALIAS_PARAM_NAMES.get(method, {}).get(field, [field])

                for param_name in aliases:
                    params = {param_name: current_value}
                    try:
                        res = client.call(method, params)
                    except Exception as e:
                        print(f"{method:30} {compact(params):45} EXCEPTION {e!r}")
                        full_results["methods"].setdefault(method, {}).setdefault("safe_setter_tests", []).append({
                            "params": params,
                            "exception": repr(e),
                        })
                        continue

                    status, code, msg = classify_response(res)
                    result = get_result(res)
                    if status == "RESULT":
                        print(f"{method:30} {compact(params):45} RESULT {compact(result)}")
                    elif status == "ERROR":
                        print(f"{method:30} {compact(params):45} ERROR code={code} msg={msg}")
                    else:
                        print(f"{method:30} {compact(params):45} OTHER {compact(res.get('response'))}")

                    full_results["methods"].setdefault(method, {}).setdefault("safe_setter_tests", []).append(res)

    if args.probe_param_names:
        print_section("4) Param name probes with invalid/null-ish values")
        print("Goal: detect -32602 Invalid params, which usually means method and param family exist.")
        print("Be careful: these are still real method calls.")

        for method, probes in PARAM_NAME_PROBES.items():
            if method not in methods and method not in baseline_results:
                continue

            for param_name, value in probes:
                params = {param_name: value}
                try:
                    res = client.call(method, params)
                except Exception as e:
                    print(f"{method:30} {compact(params):45} EXCEPTION {e!r}")
                    full_results["methods"].setdefault(method, {}).setdefault("param_name_probes", []).append({
                        "params": params,
                        "exception": repr(e),
                    })
                    continue

                status, code, msg = classify_response(res)
                result = get_result(res)
                if status == "RESULT":
                    print(f"{method:30} {compact(params):45} RESULT {compact(result)}")
                elif status == "ERROR":
                    print(f"{method:30} {compact(params):45} ERROR code={code} msg={msg}")
                else:
                    print(f"{method:30} {compact(params):45} OTHER {compact(res.get('response'))}")

                full_results["methods"].setdefault(method, {}).setdefault("param_name_probes", []).append(res)

    print_section("5) Suggested mapping from observed results")
    for method, fields in inferred_fields.items():
        print(f"{method}:")
        print("  getter:")
        print("    params: AccessToken only")
        print(f"    returns: {list(fields.keys())}")
        if method in SAFE_ECHO_SETTER_METHODS:
            print("  possible_setter_params:")
            for f in SAFE_ECHO_SETTER_METHODS[method]:
                if f in fields:
                    aliases = ALIAS_PARAM_NAMES.get(method, {}).get(f, [f])
                    print(f"    {f}: aliases={aliases} current_value={fields[f]!r}")
        print()

    try:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(full_results, f, indent=2, ensure_ascii=False)
        print(f"Full results written to: {args.json_out}")
    except Exception as e:
        print(f"Could not write JSON output: {e!r}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
