#!/usr/bin/env python3
"""
Samsung TV JSON-RPC helper for Synology.

No external Python dependency required. Uses stdlib only.

Examples:
  python3 samsung_rpc.py --host 192.168.1.31 token
  python3 samsung_rpc.py --host 192.168.1.31 state
  python3 samsung_rpc.py --host 192.168.1.31 video
  python3 samsung_rpc.py --host 192.168.1.31 key firstScreen
  python3 samsung_rpc.py --host 192.168.1.31 key cursorRight
  python3 samsung_rpc.py --host 192.168.1.31 call getTVStates
  python3 samsung_rpc.py --host 192.168.1.31 call remoteKeyControl '{"remoteKey":"return"}'
  python3 samsung_rpc.py --host 192.168.1.31 probe
"""

import argparse
import http.client
import json
import os
import ssl
import sys
from typing import Any, Dict, Optional


SAFE_PROBE_METHODS = [
    "getTVStates",
    "getVideoStates",
    "getDeviceInfo",
    "getSystemInfo",
    "getAudioStates",
    "getSoundStates",
    "getPictureStates",
    "getSourceList",
    "getInputSources",
    "getApplications",
    "getApps",
]

KNOWN_METHODS_WITH_EMPTY_PARAMS = [
    "powerControl",
    "remoteKeyControl",
    "directVolumeControl",
    "volumeUpDnControl",
    "muteControl",
    "channelUpDnControl",
    "directChannelControl",
    "inputSourceControl",
    "USBSourceControl",
    "RVUSourceControl",
    "externalSpeakerControl",
    "directAccessControl",
    "pictureModeControl",
    "pictureSizeControl",
    "soundModeControl",
    "speakerSelectControl",
    "artModeControl",
    "contrastControl",
    "brightnessControl",
    "sharpnessControl",
    "colorControl",
    "tintControl",
]


class SamsungJsonRpc:
    def __init__(self, host: str, port: int = 1516, token: Optional[str] = None, timeout: int = 10):
        self.host = host
        self.port = port
        self.token = token
        self.timeout = timeout
        self._id = 0
        self.ssl_context = ssl._create_unverified_context()

    def next_id(self) -> int:
        self._id += 1
        return self._id

    def request(self, method: str, params: Optional[Dict[str, Any]] = None, include_token: bool = True) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self.next_id(),
        }

        final_params: Dict[str, Any] = {}
        if include_token and self.token:
            final_params["AccessToken"] = self.token
        if params:
            final_params.update(params)
        if final_params:
            payload["params"] = final_params

        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")

        conn = http.client.HTTPSConnection(
            self.host,
            self.port,
            timeout=self.timeout,
            context=self.ssl_context,
        )

        try:
            conn.request(
                "POST",
                "/",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "Content-Length": str(len(body)),
                },
            )
            resp = conn.getresponse()
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                parsed: Any = json.loads(raw)
            except Exception:
                parsed = raw

            return {
                "http_status": resp.status,
                "http_reason": resp.reason,
                "request": payload,
                "response": parsed,
            }
        finally:
            conn.close()


def _script_dir() -> str:
    """Directory containing this script, resolved through any symlinks."""
    return os.path.dirname(os.path.abspath(__file__))


def token_path(host: str, port: int) -> str:
    """Token file lives next to the script (not in $HOME)."""
    return os.path.join(_script_dir(), f".samsungtv_jsonrpc_{host}_{port}.token")


def _legacy_token_path(host: str, port: int) -> str:
    """Earlier versions of this script stored tokens in $HOME — keep reading
    those so users don't have to re-pair after the path move."""
    return os.path.expanduser(f"~/.samsungtv_jsonrpc_{host}_{port}.token")


def load_token(host: str, port: int) -> Optional[str]:
    for path in (token_path(host, port), _legacy_token_path(host, port)):
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                token = f.read().strip()
                return token or None
    return None


def save_token(host: str, port: int, token: str) -> str:
    path = token_path(host, port)
    with open(path, "w", encoding="utf-8") as f:
        f.write(token + "\n")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return path


def find_token(obj: Any) -> Optional[str]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k.lower() in ("accesstoken", "access_token", "token") and isinstance(v, str):
                return v
            found = find_token(v)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = find_token(item)
            if found:
                return found
    return None


def print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=False))


def main() -> int:
    parser = argparse.ArgumentParser(description="Samsung TV JSON-RPC helper")
    parser.add_argument("--host", required=True, help="TV IP address, e.g. 192.168.1.31")
    parser.add_argument("--port", type=int, default=1516, help="JSON-RPC HTTPS port, default: 1516")
    parser.add_argument("--token", help="AccessToken. If omitted, loads ~/.samsungtv_jsonrpc_<host>_<port>.token")
    parser.add_argument("--timeout", type=int, default=10, help="HTTP timeout in seconds")

    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("token", help="Request/create an AccessToken and save it")
    sub.add_parser("state", help="Call getTVStates")
    sub.add_parser("video", help="Call getVideoStates")
    sub.add_parser("probe", help="Probe read-only and empty-param method names")

    key_p = sub.add_parser("key", help="Send a remoteKeyControl")
    key_p.add_argument("remote_key", help="Example: firstScreen, return, enter, cursorUp, cursorDn")

    call_p = sub.add_parser("call", help="Call any method with optional JSON params")
    call_p.add_argument("method")
    call_p.add_argument("params_json", nargs="?", help='Example: \'{"remoteKey":"return"}\'')

    args = parser.parse_args()

    token = args.token or load_token(args.host, args.port)
    client = SamsungJsonRpc(args.host, args.port, token=token, timeout=args.timeout)

    if args.cmd == "token":
        print("Calling createAccessToken.", file=sys.stderr)
        print("If your TV shows an authorization prompt, accept it, then rerun if needed.", file=sys.stderr)
        res = client.request("createAccessToken", include_token=False)
        print_json(res)
        found = find_token(res.get("response"))
        if found:
            path = save_token(args.host, args.port, found)
            print(f"\nAccessToken saved to: {path}")
            return 0
        print("\nNo AccessToken found in response.", file=sys.stderr)
        return 1

    if not token:
        print("No token loaded. Run first:", file=sys.stderr)
        print(f"  python3 {sys.argv[0]} --host {args.host} --port {args.port} token", file=sys.stderr)
        return 2

    if args.cmd == "state":
        print_json(client.request("getTVStates"))
        return 0

    if args.cmd == "video":
        print_json(client.request("getVideoStates"))
        return 0

    if args.cmd == "key":
        print_json(client.request("remoteKeyControl", {"remoteKey": args.remote_key}))
        return 0

    if args.cmd == "call":
        params = None
        if args.params_json:
            try:
                params = json.loads(args.params_json)
                if not isinstance(params, dict):
                    raise ValueError("params_json must decode to a JSON object")
            except Exception as e:
                print(f"Invalid params_json: {e}", file=sys.stderr)
                return 3
        print_json(client.request(args.method, params))
        return 0

    if args.cmd == "probe":
        print("=== Safe/read-only probes ===")
        for m in SAFE_PROBE_METHODS:
            try:
                res = client.request(m)
                response = res.get("response")
                if isinstance(response, dict) and "result" in response:
                    verdict = "RESULT"
                elif isinstance(response, dict) and "error" in response:
                    err = response.get("error")
                    verdict = f"ERROR {err}"
                else:
                    verdict = f"OTHER {response!r}"
                print(f"{m:28} HTTP={res.get('http_status')} {verdict}")
            except Exception as e:
                print(f"{m:28} EXCEPTION {e!r}")

        print("\n=== Known methods with empty params: useful to classify errors only ===")
        print("These calls should normally fail with missing/invalid parameter if the method exists.")
        for m in KNOWN_METHODS_WITH_EMPTY_PARAMS:
            try:
                res = client.request(m)
                response = res.get("response")
                if isinstance(response, dict) and "result" in response:
                    verdict = "RESULT"
                elif isinstance(response, dict) and "error" in response:
                    err = response.get("error")
                    verdict = f"ERROR {err}"
                else:
                    verdict = f"OTHER {response!r}"
                print(f"{m:28} HTTP={res.get('http_status')} {verdict}")
            except Exception as e:
                print(f"{m:28} EXCEPTION {e!r}")
        return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
