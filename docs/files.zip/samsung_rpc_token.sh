#!/bin/sh
# Samsung TV JSON-RPC token helper for Synology / BusyBox shells
# Usage:
#   ./samsung_rpc_token.sh 192.168.1.31
#   ./samsung_rpc_token.sh 192.168.1.31 1516

set -eu

TV="${1:-}"
PORT="${2:-1516}"

if [ -z "$TV" ]; then
  echo "Usage: $0 <tv_ip> [port]"
  echo "Example: $0 192.168.1.31 1516"
  exit 1
fi

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required."
  exit 2
fi

OUT="/tmp/samsung_create_token_${TV}_${PORT}.json"

# Resolve the directory of this script. POSIX-portable; works even on BusyBox /
# Synology shells. Falls back to PWD if something exotic prevents resolution.
SCRIPT_DIR="$(cd "$(dirname -- "$0")" 2>/dev/null && pwd || echo "$PWD")"
TOKEN_FILE="${SCRIPT_DIR}/.samsungtv_jsonrpc_${TV}_${PORT}.token"
LEGACY_TOKEN_FILE="$HOME/.samsungtv_jsonrpc_${TV}_${PORT}.token"

# If an older run stored the token in $HOME (the previous location), migrate it
# next to the script on first use of the new version. Best-effort; never fail.
if [ ! -f "$TOKEN_FILE" ] && [ -f "$LEGACY_TOKEN_FILE" ]; then
  if cp "$LEGACY_TOKEN_FILE" "$TOKEN_FILE" 2>/dev/null; then
    echo "Migrated existing token from $LEGACY_TOKEN_FILE -> $TOKEN_FILE"
    chmod 600 "$TOKEN_FILE" 2>/dev/null || true
  fi
fi

echo "Calling createAccessToken on https://${TV}:${PORT}/ ..."
echo "If your TV shows an authorization prompt, accept it."

curl -k -sS -i \
  --connect-timeout 5 \
  --max-time 20 \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -X POST "https://${TV}:${PORT}/" \
  --data '{"jsonrpc":"2.0","method":"createAccessToken","id":1}' \
  > "$OUT" || {
    echo "ERROR: curl failed."
    echo "Raw output, if any: $OUT"
    exit 3
  }

echo
echo "Raw response saved to: $OUT"
echo "---- response headers/body preview ----"
head -n 80 "$OUT"
echo "---------------------------------------"

BODY="$(sed '1,/^\r\{0,1\}$/d' "$OUT" | tr -d '\r')"

TOKEN=""
if command -v python3 >/dev/null 2>&1; then
  TOKEN="$(printf '%s' "$BODY" | python3 -c '
import json, sys
text=sys.stdin.read().strip()
try:
    obj=json.loads(text)
except Exception:
    print("")
    raise SystemExit
def walk(x):
    if isinstance(x, dict):
        for k,v in x.items():
            if k.lower() in ("accesstoken","access_token","token") and isinstance(v, str):
                print(v); return True
            if walk(v): return True
    elif isinstance(x, list):
        for v in x:
            if walk(v): return True
    return False
walk(obj)
' 2>/dev/null | head -n 1)"
fi

if [ -z "$TOKEN" ]; then
  TOKEN="$(printf '%s' "$BODY" | sed -n 's/.*"AccessToken"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)"
fi

if [ -z "$TOKEN" ]; then
  TOKEN="$(printf '%s' "$BODY" | sed -n 's/.*"accessToken"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1)"
fi

echo
if [ -n "$TOKEN" ]; then
  printf '%s\n' "$TOKEN" > "$TOKEN_FILE"
  chmod 600 "$TOKEN_FILE" 2>/dev/null || true
  echo "Token extracted and saved to:"
  echo "  $TOKEN_FILE"
  echo
  echo "Test getTVStates:"
  curl -k -sS -i \
    --connect-timeout 5 \
    --max-time 15 \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -X POST "https://${TV}:${PORT}/" \
    --data "{\"jsonrpc\":\"2.0\",\"method\":\"getTVStates\",\"id\":2,\"params\":{\"AccessToken\":\"$TOKEN\"}}"
  echo
else
  echo "No token could be extracted automatically."
  echo "Look at the response above. If the TV asked for authorization, accept it and rerun this script."
  echo "If the token is present under another field name, copy it manually into:"
  echo "  $TOKEN_FILE"
fi
